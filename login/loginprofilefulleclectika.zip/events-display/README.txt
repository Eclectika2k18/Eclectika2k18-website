A Pen created at CodePen.io. You can find this one at https://codepen.io/chrishutchinson/pen/nafEp.

 Testing some simple animations to separate stacks of cards